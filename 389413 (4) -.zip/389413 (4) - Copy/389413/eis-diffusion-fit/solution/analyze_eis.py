"""Reference analysis of multi-temperature impedance spectra (semi-infinite vs finite-length Warburg).

Usage:
    python3 analyze_eis.py --input-dir INPUT_DIRECTORY --output OUTPUT_JSON

Conventions (j**2 = -1, omega = 2*pi*f, Z = zre + j*zim):
    Z_meas = R_fix + j*omega*L_fix + R_s + 1/(1/R_ct + Q*(j*omega)**alpha) + Z_D
    Z_D(semi-infinite) = sigma*(1 - j)/sqrt(omega)
    Z_D(finite-length) = R_D*tanh(sqrt(j*omega*tau_D))/sqrt(j*omega*tau_D)

Every temperature has its own independent parameter set. Each model is fitted by minimising the
modulus-weighted residual sum of squares; the two models are compared with a pooled AICc and the
finite-length model is selected only when AICc(semi) - AICc(finite) > 10. R_ct(T) is then regressed
on 1/T (ordinary least squares on ln R_ct) to obtain the apparent activation energy.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import sys

import numpy as np
from scipy.optimize import least_squares

R_GAS = 8.314462618          # J mol^-1 K^-1
T_REF = 298.15               # K
AICC_THRESHOLD = 10.0        # finite-length is selected only if AICc_semi - AICc_finite exceeds this
N_PARAMS_PER_T = {"semi_infinite": 5, "finite_length": 6}
RNG_SEED = 20261012
N_RANDOM_STARTS = {"semi_infinite": 24, "finite_length": 24}

# log-space bounds for [R_s, R_ct, Q, alpha, sigma(_eff), tau_D]; alpha is optimised directly
_LO = np.array([math.log(1e-3), math.log(1e-2), math.log(1e-9), 0.5, math.log(1e-4), math.log(1e-3)])
_HI = np.array([math.log(1e3), math.log(1e5), math.log(1.0), 1.0, math.log(1e4), math.log(1e6)])


# ----------------------------------------------------------------------------- physics
def z_cell(omega, x, model):
    """Cell impedance (no fixture) for the parameter vector x = [ln R_s, ln R_ct, ln Q, alpha, ln sigma, (ln tau_D)].

    For the finite-length model the free parameters are (sigma_eff, tau_D) with R_D = sigma_eff*sqrt(2*tau_D),
    i.e. sigma_eff = R_D/sqrt(2*tau_D) is the high-frequency Warburg coefficient (a reparametrisation of (R_D, tau_D)).
    """
    r_s, r_ct, q = math.exp(x[0]), math.exp(x[1]), math.exp(x[2])
    alpha = x[3]
    cpe = q * omega ** alpha * np.exp(1j * math.pi * alpha / 2.0)          # Q*(j*omega)**alpha
    z = r_s + 1.0 / (1.0 / r_ct + cpe)
    sigma = math.exp(x[4])
    if model == "semi_infinite":
        return z + sigma * (1.0 - 1j) / np.sqrt(omega)
    tau = math.exp(x[5])
    r_d = sigma * math.sqrt(2.0 * tau)
    arg = np.sqrt(omega * tau) * np.exp(1j * math.pi / 4.0)                 # sqrt(j*omega*tau_D)
    e = np.exp(-2.0 * arg)                                                  # tanh(arg) = (1-e)/(1+e), Re(arg) > 0
    return z + r_d * ((1.0 - e) / (1.0 + e)) / arg


def physical_parameters(x, model):
    p = {"r_s_ohm": math.exp(x[0]), "r_ct_ohm": math.exp(x[1]), "cpe_q": math.exp(x[2]), "cpe_alpha": float(x[3]),
         "warburg_sigma": math.exp(x[4]), "r_d_ohm": None, "tau_d_s": None}
    if model == "finite_length":
        tau = math.exp(x[5])
        p["tau_d_s"] = tau
        p["r_d_ohm"] = p["warburg_sigma"] * math.sqrt(2.0 * tau)
    return p


# ----------------------------------------------------------------------------- fitting
class Block:
    """All data of one temperature: fixture-corrected impedance and the modulus weights of the RAW rows."""

    def __init__(self, temperature, freq, zre, zim, r_fix, l_fix):
        order = np.argsort(-freq)
        self.temperature = float(temperature)
        self.freq = freq[order]
        self.omega = 2.0 * math.pi * self.freq
        raw = zre[order] + 1j * zim[order]
        self.weight = 1.0 / np.abs(raw)
        self.zc = raw - (r_fix + 1j * self.omega * l_fix)                    # remove R_fix + j*omega*L_fix

    def residuals(self, x, model):
        d = (self.zc - z_cell(self.omega, x, model)) * self.weight
        return np.concatenate([d.real, d.imag])


def _bounds(model):
    n = N_PARAMS_PER_T[model]
    return _LO[:n], _HI[:n]


def _random_start(block, model, rng):
    re, im = block.zc.real, block.zc.imag
    w_min, w_max = block.omega.min(), block.omega.max()
    rs_hi = max(float(re.min()), 1e-3)
    re_low = float(re[np.argmin(block.omega)])
    span = max(re_low - rs_hi, 1e-2)
    sig_est = max(float(-im[np.argmin(block.omega)]) * math.sqrt(w_min), 1e-3)
    rs0 = rs_hi * rng.uniform(0.5, 1.0)
    rct0 = span * 10.0 ** rng.uniform(-1.3, 0.0)
    a0 = rng.uniform(0.7, 1.0)
    w_apex = 10.0 ** rng.uniform(math.log10(w_min * 10.0), math.log10(w_max / 10.0))
    q0 = w_apex ** (-a0) / rct0
    s0 = sig_est * 10.0 ** rng.uniform(-1.0, 0.5)
    x = [math.log(rs0), math.log(rct0), math.log(q0), a0, math.log(s0)]
    if model == "finite_length":
        x.append(math.log(10.0 ** rng.uniform(math.log10(1.0 / w_max), math.log10(30.0 / w_min))))
    return np.array(x)


def _local_fit(block, model, x0):
    lo, hi = _bounds(model)
    x0 = np.clip(x0, lo + 1e-9, hi - 1e-9)
    try:
        res = least_squares(block.residuals, x0, args=(model,), bounds=(lo, hi), method="trf", x_scale="jac",
                            xtol=1e-12, ftol=1e-12, gtol=1e-12, max_nfev=400)
    except (ValueError, FloatingPointError, np.linalg.LinAlgError):
        return None
    rss = float(np.sum(res.fun ** 2))
    if not math.isfinite(rss):
        return None
    return {"x": res.x.copy(), "rss": rss}


def fit_block(block, model, rng, extra_starts=()):
    best = None
    starts = [np.asarray(s, float) for s in extra_starts]
    starts += [_random_start(block, model, rng) for _ in range(N_RANDOM_STARTS[model])]
    for x0 in starts:
        cand = _local_fit(block, model, x0)
        if cand is not None and (best is None or cand["rss"] < best["rss"]):
            best = cand
    if best is None:
        raise RuntimeError(f"no converged fit for model {model} at T={block.temperature} K")
    return best


def fit_all(blocks, rng):
    """Fit both models at every temperature; neighbouring-temperature solutions are re-used as extra starts."""
    fits = {m: [None] * len(blocks) for m in N_PARAMS_PER_T}
    for i, blk in enumerate(blocks):
        semi_extra = [fits["semi_infinite"][i - 1]["x"]] if i else []
        fits["semi_infinite"][i] = fit_block(blk, "semi_infinite", rng, semi_extra)
        base = fits["semi_infinite"][i]["x"]
        fin_extra = [np.append(base, math.log(t)) for t in (1.0, 5.0, 25.0, 125.0, 1000.0, 1e4, 1e5)]
        if i:
            fin_extra.append(fits["finite_length"][i - 1]["x"])
        fits["finite_length"][i] = fit_block(blk, "finite_length", rng, fin_extra)
    # second pass: try the neighbours' solutions at every temperature (catches blocks stuck in a poor local minimum)
    for _ in range(2):
        changed = False
        for model in N_PARAMS_PER_T:
            for i, blk in enumerate(blocks):
                extra = [fits[model][j]["x"] for j in (i - 1, i + 1) if 0 <= j < len(blocks)]
                for x0 in extra:
                    cand = _local_fit(blk, model, x0)
                    if cand is not None and cand["rss"] < fits[model][i]["rss"] * (1.0 - 1e-9):
                        fits[model][i] = cand
                        changed = True
        if not changed:
            break
    return fits


def aicc(rss, n_obs, k):
    return n_obs * math.log(rss / n_obs) + 2.0 * k + 2.0 * k * (k + 1.0) / (n_obs - k - 1.0)


# ----------------------------------------------------------------------------- I/O
def load_dataset(input_dir):
    meta_path = os.path.join(input_dir, "metadata.json")
    csv_path = os.path.join(input_dir, "spectra.csv")
    with open(meta_path, "r", encoding="utf-8") as fh:
        meta = json.load(fh)
    rows = []
    with open(csv_path, "r", encoding="utf-8", newline="") as fh:
        for rec in csv.DictReader(fh):
            rows.append((float(rec["temperature_k"]), float(rec["frequency_hz"]), float(rec["zre_ohm"]), float(rec["zim_ohm"])))
    arr = np.array(rows, float)
    fix = meta["fixture"]
    r_fix, l_fix = float(fix["series_resistance_ohm"]), float(fix["series_inductance_h"])
    blocks = []
    for t in sorted(set(arr[:, 0])):
        sel = arr[:, 0] == t
        blocks.append(Block(t, arr[sel, 1], arr[sel, 2], arr[sel, 3], r_fix, l_fix))
    pred_f = np.array([float(f) for f in meta["prediction_frequencies_hz"]], float)
    return meta, blocks, pred_f, int(arr.shape[0])


def analyse(input_dir):
    meta, blocks, pred_f, n_rows = load_dataset(input_dir)
    rng = np.random.default_rng(RNG_SEED)
    fits = fit_all(blocks, rng)
    n_obs = 2 * n_rows
    n_t = len(blocks)
    stats = {}
    for model in N_PARAMS_PER_T:
        rss = float(sum(f["rss"] for f in fits[model]))
        k = N_PARAMS_PER_T[model] * n_t + 1               # +1: the common relative error variance
        stats[model] = {"n_params": k, "rss": rss, "aicc": aicc(rss, n_obs, k)}
    delta = stats["semi_infinite"]["aicc"] - stats["finite_length"]["aicc"]
    selected = "finite_length" if delta > AICC_THRESHOLD else "semi_infinite"
    evidence = "favors_finite_length" if delta > AICC_THRESHOLD else ("favors_semi_infinite" if delta < -AICC_THRESHOLD else "inconclusive")
    # both parameter sets are reported (the verifier recomputes each RSS from them); `temperatures` repeats the selected one
    params = {m: [{"temperature_k": blk.temperature, **physical_parameters(fit["x"], m)} for blk, fit in zip(blocks, fits[m])]
              for m in N_PARAMS_PER_T}
    temps_out = params[selected]
    r_ct = [p["r_ct_ohm"] for p in temps_out]
    pred_re, pred_im = [], []
    for fit in fits[selected]:
        zp = z_cell(2.0 * math.pi * pred_f, fit["x"], selected)
        pred_re.append([float(v) for v in zp.real])
        pred_im.append([float(v) for v in zp.imag])
    inv_t = 1.0 / np.array([b.temperature for b in blocks])
    slope, intercept = np.polyfit(inv_t, np.log(np.array(r_ct)), 1)
    out = {
        "dataset_id": meta["dataset_id"],
        "model_comparison": {
            "n_obs": n_obs,
            "semi_infinite": {**stats["semi_infinite"], "parameters": params["semi_infinite"]},
            "finite_length": {**stats["finite_length"], "parameters": params["finite_length"]},
            "delta_aicc": delta,
            "evidence": evidence,
            "selected_model": selected,
        },
        "temperatures": temps_out,
        "arrhenius": {
            "activation_energy_kj_mol": float(slope) * R_GAS / 1000.0,
            "r_ct_298_15k_ohm": float(math.exp(intercept + slope / T_REF)),
        },
        "predictions": {"frequency_hz": [float(f) for f in pred_f], "cell_zre_ohm": pred_re, "cell_zim_ohm": pred_im},
    }
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description="Fit multi-temperature EIS spectra and select the diffusion model.")
    ap.add_argument("--input-dir", required=True, help="directory holding spectra.csv and metadata.json")
    ap.add_argument("--output", required=True, help="path of the JSON file to write")
    args = ap.parse_args(argv)
    result = analyse(args.input_dir)
    out_dir = os.path.dirname(os.path.abspath(args.output))
    os.makedirs(out_dir, exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as fh:
        json.dump(result, fh, indent=2, allow_nan=False)
        fh.write("\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
